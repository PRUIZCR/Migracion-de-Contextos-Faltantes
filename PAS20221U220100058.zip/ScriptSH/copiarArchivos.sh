#!/bin/bash

fecha=$(date "+%Y-%m-%d %H:%M:%S");

Host=<ip host>
User=<user>
Port=<puerto>
Password=<password>
directorioRemoto="htdocs/sunat"
directorioLocal="/htdocs/sunat_ssl"

FileName=archivos.txt

echo "[$fecha] Iniciando la descarga de archivos sftp";
while IFS= read -r line
do
  archivo="$line"
  echo "sftp://$Host:$Port/$directorioRemoto$archivo"
  echo "$directorioLocal$archivo"
  curl  -k "sftp://$Host:$Port/$directorioRemoto$archivo" --user "$User:$Password" -o "$directorioLocal$archivo" --create-dirs
done < "$FileName"

echo "[$fecha] Finalizando la descarga de archivos sftp";